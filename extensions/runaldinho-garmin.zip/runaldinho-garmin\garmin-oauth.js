/**
 * Kaiord Garmin Bridge — OAuth token minting (bridge-specific, NOT vendored)
 *
 * Replaces the cookie/CSRF relay with a portable OAuth token. The user's
 * existing connect.garmin.com session is exchanged ONCE for OAuth tokens
 * (no password prompt); thereafter the service worker calls
 * connectapi.garmin.com directly with `Authorization: Bearer`.
 *
 * Flow (a JS port of garth's sso.py, verified against the live API):
 *   1. getTicketFromSession — the browser's SSO session (cookie CASTGC on
 *      sso.garmin.com) issues a service ticket for the mobile service
 *      WITHOUT re-authenticating.
 *   2. preauthorized — OAuth1-sign (2-legged) the ticket → OAuth1 token.
 *   3. exchange       — OAuth1-sign (3-legged) → OAuth2 Bearer token.
 * The OAuth2 access token is refreshed by re-running `exchange` with the
 * long-lived OAuth1 token (~1 year); if that fails, we re-mint from the
 * session. Tokens live in chrome.storage.local (survive SW cold starts).
 *
 * The consumer key/secret are Garmin's public reverse-engineered values
 * (same as garth / thegarth.s3.amazonaws.com/oauth_consumer.json). Hardcoded
 * so the bridge needs no extra host permission; bump if Garmin rotates them.
 */

const CONSUMER = {
  key: "fc3e99d2-118c-44b8-8ae3-03370dde24c0",
  secret: "E08WAR897WEy2knn7aFBrvegVAf0AFdWBBF",
};
const CONNECTAPI = "https://connectapi.garmin.com";
const SSO_SIGNIN = "https://sso.garmin.com/sso/signin";
const CLIENT_ID = "GCM_ANDROID_DARK";
const LOGIN_URL = "https://mobile.integration.garmin.com/gcm/android";
const OAUTH1_KEY = "garminOAuth1";
const OAUTH2_KEY = "garminOAuth2";
const EXPIRY_SKEW_SEC = 60;

// The credential-handshake surface: every endpoint the three hops below send
// the user's Garmin session to, in flow order. Read by
// scripts/check-bridge-privacy-surface.mjs into the golden fixture, which
// otherwise locks only the DATA-call allowlist in background.js — a gate
// this handshake bypasses by construction.
//
// Written out in full rather than composed from CONNECTAPI/SSO_SIGNIN: the
// guard records string literals, and an interpolated `${CONNECTAPI}/…` would
// reach the golden as placeholder text. garmin-oauth.test.js pins this list
// against the URLs the flow actually requests, so the duplication cannot
// drift from the calls it describes.
const AUTH_ENDPOINTS = [
  "https://sso.garmin.com/sso/signin",
  "https://connectapi.garmin.com/oauth-service/oauth/preauthorized",
  "https://connectapi.garmin.com/oauth-service/oauth/exchange/user/2.0",
];

const nowSec = () => Math.floor(Date.now() / 1000);

// ── OAuth1 HMAC-SHA1 signer (verified byte-for-byte against oauth-1.0a) ──

// RFC-3986 percent-encoding as OAuth1 requires.
const enc = (s) =>
  encodeURIComponent(s).replace(
    /[!*'()]/g,
    (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase()
  );

const nonce = () => {
  const a = new Uint8Array(16);
  crypto.getRandomValues(a);
  return [...a].map((b) => b.toString(16).padStart(2, "0")).join("");
};

// Web Crypto HMAC-SHA1 — the same code path in the service worker and in the
// Node test runner (both expose globalThis.crypto.subtle).
const hmacSha1B64 = async (keyStr, baseStr) => {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(keyStr),
    { name: "HMAC", hash: "SHA-1" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(baseStr)
  );
  return btoa(String.fromCharCode(...new Uint8Array(sig)));
};

/**
 * Build an `Authorization: OAuth …` header. `extraParams` are non-query
 * params folded into the signature base (the POST body for exchange).
 * `token` (the resource-owner {key, secret}) makes it a 3-legged signature.
 */
const sign = async (method, url, extraParams, token) => {
  const u = new URL(url);
  const baseUrl = u.origin + u.pathname;

  const oauth = {
    oauth_consumer_key: CONSUMER.key,
    oauth_nonce: nonce(),
    oauth_signature_method: "HMAC-SHA1",
    oauth_timestamp: String(nowSec()),
    oauth_version: "1.0",
  };
  if (token) oauth.oauth_token = token.key;

  const all = {};
  for (const [k, v] of u.searchParams) all[k] = v;
  for (const k in extraParams) all[k] = extraParams[k];
  for (const k in oauth) all[k] = oauth[k];

  const paramStr = Object.keys(all)
    .sort()
    .map((k) => `${enc(k)}=${enc(all[k])}`)
    .join("&");
  const base = [method.toUpperCase(), enc(baseUrl), enc(paramStr)].join("&");
  const signingKey = `${enc(CONSUMER.secret)}&${token ? enc(token.secret) : ""}`;
  oauth.oauth_signature = await hmacSha1B64(signingKey, base);

  return (
    "OAuth " +
    Object.keys(oauth)
      .sort()
      .map((k) => `${enc(k)}="${enc(oauth[k])}"`)
      .join(", ")
  );
};

// ── Auth errors carry needsReauth so the SPA can prompt a Garmin login ──

const authError = (stage, status) => {
  const err = new Error(
    stage === "ticket"
      ? "No Garmin session. Open Garmin Connect, sign in, then retry."
      : `Garmin auth failed at ${stage}${status ? ` (${status})` : ""}`
  );
  err.needsReauth = true;
  err.retryable = true;
  return err;
};

// ── Minting: session → ticket → OAuth1 → OAuth2 ──

const getTicketFromSession = async (fetchImpl) => {
  const url = `${SSO_SIGNIN}?${new URLSearchParams({
    service: LOGIN_URL,
    clientId: CLIENT_ID,
    gauthHost: "https://sso.garmin.com/sso",
    locale: "en_US",
  })}`;
  const r = await fetchImpl(url, {
    credentials: "include",
    headers: {
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    },
  });
  const html = await r.text();
  const m = html.match(/ticket=([A-Za-z0-9-]+)/);
  if (!m) throw authError("ticket");
  return m[1];
};

const preauthorized = async (ticket, fetchImpl) => {
  const url =
    `${CONNECTAPI}/oauth-service/oauth/preauthorized` +
    `?ticket=${enc(ticket)}&login-url=${enc(LOGIN_URL)}&accepts-mfa-tokens=true`;
  const auth = await sign("GET", url, {}, null);
  const r = await fetchImpl(url, {
    headers: { Authorization: auth },
    credentials: "include",
  });
  if (!r.ok) throw authError("preauthorized", r.status);
  const p = new URLSearchParams(await r.text());
  const oauth_token = p.get("oauth_token");
  const oauth_token_secret = p.get("oauth_token_secret");
  if (!oauth_token || !oauth_token_secret) throw authError("preauthorized");
  return { oauth_token, oauth_token_secret };
};

// Also serves as the OAuth2 refresh: re-exchanging the OAuth1 token mints a
// fresh Bearer.
//
// This call carries TWO things Garmin could be authenticating it by, and
// which one it accepts is unknown from here. It is signed with the OAuth1
// token (the `Authorization` header built below). It is ALSO sent with
// `credentials: "include"`, so the browser attaches whatever ambient Garmin
// cookies it holds — the extension has no `cookies` permission and never
// READS one, but not reading is not the same as not sending. #1102 is meant
// to settle which is required; until then claim neither. (The data calls are
// the deliberate contrast: bearer-fetch.js sends `credentials: "omit"` so the
// Bearer really is the only credential there.)
//
// This comment used to say the refresh happened "without touching the
// session". It was copied into the bridge spec on trust and shipped there
// before anyone read the request ten lines below it.
const exchange = async (oauth1, fetchImpl) => {
  const url = `${CONNECTAPI}/oauth-service/oauth/exchange/user/2.0`;
  const bodyParams = { audience: "GARMIN_CONNECT_MOBILE_ANDROID_DI" };
  const auth = await sign("POST", url, bodyParams, {
    key: oauth1.oauth_token,
    secret: oauth1.oauth_token_secret,
  });
  const r = await fetchImpl(url, {
    method: "POST",
    headers: {
      Authorization: auth,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams(bodyParams).toString(),
    credentials: "include",
  });
  if (!r.ok) throw authError("exchange", r.status);
  const t = await r.json();
  t.expires_at = nowSec() + (Number(t.expires_in) || 0);
  return t;
};

const mintFromSession = async (fetchImpl) => {
  const ticket = await getTicketFromSession(fetchImpl);
  const oauth1 = await preauthorized(ticket, fetchImpl);
  const oauth2 = await exchange(oauth1, fetchImpl);
  return { oauth1, oauth2 };
};

// ── Token store (chrome.storage.local; survives SW cold starts) ──

const loadTokens = async () => {
  const r = await chrome.storage.local.get([OAUTH1_KEY, OAUTH2_KEY]);
  return { oauth1: r[OAUTH1_KEY] ?? null, oauth2: r[OAUTH2_KEY] ?? null };
};

const saveTokens = ({ oauth1, oauth2 }) =>
  chrome.storage.local.set({ [OAUTH1_KEY]: oauth1, [OAUTH2_KEY]: oauth2 });

const clearTokens = () => chrome.storage.local.remove([OAUTH1_KEY, OAUTH2_KEY]);

const isOAuth2Expired = (oauth2) =>
  !oauth2 ||
  typeof oauth2.expires_at !== "number" ||
  oauth2.expires_at - EXPIRY_SKEW_SEC <= nowSec();

const isAbortError = (e) =>
  e?.name === "AbortError" || e?.name === "TimeoutError";

// Single-flight the 3-hop mint so a cold-start stampede (ping + snapshot +
// activities firing at once) does not run it three times.
let mintInFlight = null;
const mintAndSave = (fetchImpl) => {
  if (!mintInFlight) {
    mintInFlight = mintFromSession(fetchImpl)
      .then(async (tokens) => {
        await saveTokens(tokens);
        return tokens;
      })
      .finally(() => {
        mintInFlight = null;
      });
  }
  return mintInFlight;
};

// Return a usable {oauth1, oauth2}, minting or refreshing + persisting as
// needed.
const ensureToken = async (fetchImpl) => {
  const tokens = await loadTokens();
  if (!tokens.oauth1 || !tokens.oauth2) return mintAndSave(fetchImpl);
  if (isOAuth2Expired(tokens.oauth2)) {
    try {
      const oauth2 = await exchange(tokens.oauth1, fetchImpl);
      const refreshed = { oauth1: tokens.oauth1, oauth2 };
      await saveTokens(refreshed);
      return refreshed;
    } catch (e) {
      // An aborted refresh says nothing about the OAuth1 token: re-minting
      // from the session would start a mint on a caller that gave up.
      if (isAbortError(e)) throw e;
      return mintAndSave(fetchImpl); // OAuth1 dead → re-mint from session
    }
  }
  return tokens;
};

// ── Bearer transport (shared identity-free master) ──
//
// The raw Bearer fetch + 401→re-mint retry live in the vendored bridge-core
// `bearer-fetch.js` master; this module injects only the Garmin base URL and
// the token lifecycle. In the service worker the master is loaded via
// importScripts and exposed on `self`; in Node tests it resolves via require.
let bearerCoreCache;
const bearerCore = () => {
  if (bearerCoreCache) return bearerCoreCache;
  bearerCoreCache =
    typeof require !== "undefined"
      ? require("./bearer-fetch.js")
      : { bearerFetch: self.bearerFetch, bearerRequest: self.bearerRequest };
  return bearerCoreCache;
};

const accessTokenAfterEnsure = async (fetchImpl) =>
  (await ensureToken(fetchImpl)).oauth2.access_token;
const accessTokenAfterMint = async (fetchImpl) =>
  (await mintAndSave(fetchImpl)).oauth2.access_token;

// Settle with the promise `start()` returns, or reject with the signal's
// reason as soon as it aborts. Injecting the signal through `fetchImpl` is
// not enough on its own: a caller that JOINS `mintInFlight` awaits a mint
// built with the first caller's fetch, which never sees this signal. Racing
// stops this caller waiting; the mint keeps running for its other waiters.
// `start` is a thunk so an already-aborted signal starts nothing.
const raceAbort = (start, signal) => {
  if (!signal) return start();
  if (signal.aborted) return Promise.reject(signal.reason);
  const promise = start();
  return new Promise((resolve, reject) => {
    const onAbort = () => reject(signal.reason);
    signal.addEventListener("abort", onAbort, { once: true });
    void promise
      .then(resolve, reject)
      .finally(() => signal.removeEventListener("abort", onAbort));
  });
};

/**
 * The bridge's Garmin JSON call surface. Returns the same envelope the old
 * content-script relay did: { ok, status, data } | { ok:false, status, body }.
 * A 401 (token rejected despite not being expired) triggers one re-mint and
 * retry; a still-401 retry surfaces `needsReauth` so the SPA can prompt a
 * Garmin re-login.
 *
 * With a deadline `signal`, `fetchImpl` carries it and bounds the request
 * itself, while the token lifecycle (refresh, mint, re-mint) runs on the
 * untimed `tokenFetchImpl` and only this caller's wait is raced against the
 * signal. A mint other callers can join must never see one caller's
 * deadline: aborting it would fail them with an error that is not theirs.
 */
const connectapiFetch = (
  path,
  method,
  body,
  fetchImpl,
  { signal, tokenFetchImpl = fetchImpl } = {}
) =>
  bearerCore().bearerRequest({
    baseUrl: CONNECTAPI,
    path,
    method,
    body,
    getToken: () =>
      raceAbort(() => accessTokenAfterEnsure(tokenFetchImpl), signal),
    refreshToken: () =>
      raceAbort(() => accessTokenAfterMint(tokenFetchImpl), signal),
    fetchImpl,
  });

/**
 * Multipart upload surface: POSTs a `FormData` (e.g. a FIT file) through the
 * SAME Bearer + 401→re-mint lifecycle as `connectapiFetch`. The master leaves
 * the Content-Type unset so the runtime attaches the multipart boundary.
 */
const connectapiUpload = (path, formData, fetchImpl) =>
  bearerCore().bearerRequest({
    baseUrl: CONNECTAPI,
    path,
    method: "POST",
    body: formData,
    getToken: accessTokenAfterEnsure,
    refreshToken: accessTokenAfterMint,
    fetchImpl,
  });

const api = {
  CONSUMER,
  CONNECTAPI,
  AUTH_ENDPOINTS,
  sign,
  getTicketFromSession,
  preauthorized,
  exchange,
  refresh: exchange,
  mintFromSession,
  loadTokens,
  saveTokens,
  clearTokens,
  isOAuth2Expired,
  ensureToken,
  isAbortError,
  raceAbort,
  connectapiFetch,
  connectapiUpload,
};

if (typeof module !== "undefined") {
  module.exports = api;
} else if (typeof self !== "undefined") {
  self.garminOAuth = api;
}
