/**
 * Garmin sign-in page: hosts Garmin's embed widget in an iframe so the user
 * signs in (MFA included) on Garmin's own page. When the widget hands back a
 * CAS service ticket, it goes to the service worker, which exchanges it for a
 * DI token; the tab then closes.
 */

const GARMIN_ORIGIN = "https://sso.garmin.com";
const EMBED_PATH = "/sso/embed";

const embedUrl = () => {
  const source = `${location.origin}${location.pathname}`;
  const params = new URLSearchParams({
    clientId: "GarminConnect",
    locale: "en_US",
    id: "gauth-widget",
    embedWidget: "true",
    gauthHost: `${GARMIN_ORIGIN}/sso`,
    service: `${GARMIN_ORIGIN}${EMBED_PATH}`,
    source,
    consumeServiceTicket: "false",
    redirectAfterAccountLoginUrl: `${GARMIN_ORIGIN}${EMBED_PATH}`,
    redirectAfterAccountCreationUrl: `${GARMIN_ORIGIN}${EMBED_PATH}`,
  });
  return `${GARMIN_ORIGIN}${EMBED_PATH}?${params.toString()}`;
};

const showDone = (message) => {
  document.body.replaceChildren();
  const el = document.createElement("div");
  el.className = "done";
  el.textContent = message;
  document.body.appendChild(el);
};

const ticketFrom = (event) => {
  if (event.origin !== GARMIN_ORIGIN) return null;
  const raw = typeof event.data === "string" ? event.data : event.data?.data;
  if (!raw) return null;
  try {
    const parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
    return parsed?.serviceTicket ?? null;
  } catch {
    return null;
  }
};

window.addEventListener("message", (event) => {
  const ticket = ticketFrom(event);
  if (!ticket) return;
  showDone("Sending the Garmin ticket to the extension…");
  chrome.runtime.sendMessage({ action: "save-ticket", ticket }, (res) => {
    const lastError = chrome.runtime.lastError?.message;
    console.info("save-ticket response", res, lastError);
    if (res?.ok) {
      showDone("Garmin connected. You can close this tab.");
      setTimeout(() => window.close(), 1200);
    } else {
      showDone(`Could not save: ${lastError || res?.error || "no response"}`);
    }
  });
});

document.getElementById("garmin-login").src = embedUrl();